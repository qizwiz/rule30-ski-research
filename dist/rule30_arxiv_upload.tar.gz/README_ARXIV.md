Main file: rule30_rheology.tex
Supplementary artifact: InterBasin.lean (Lean 4 proof source)
